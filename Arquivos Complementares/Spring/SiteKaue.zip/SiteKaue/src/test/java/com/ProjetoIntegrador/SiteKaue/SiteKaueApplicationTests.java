package com.ProjetoIntegrador.SiteKaue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteKaueApplicationTests {

	@Test
	void contextLoads() {
	}

}
