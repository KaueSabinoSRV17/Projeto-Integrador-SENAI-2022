package com.ProjetoIntegrador.SiteKaue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteKaueApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteKaueApplication.class, args);
	}

}
